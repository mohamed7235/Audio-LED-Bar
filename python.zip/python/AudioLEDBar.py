import sys
import os
import warnings
import numpy as np
import sounddevice as sd
import serial
import serial.tools.list_ports

warnings.filterwarnings("ignore", category=DeprecationWarning)

from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QComboBox, QPushButton, QLabel, QSlider, QSizePolicy, QDialog,
    QDialogButtonBox, QMenuBar, QAction
)
from PyQt5.QtCore import Qt, QTimer, pyqtSignal, QObject, QSize
from PyQt5.QtGui import (
    QPainter, QColor, QLinearGradient, QFont, QPen, QBrush,
    QIcon, QPixmap, QImage
)

# ===================== إعدادات عامة =====================
APP_NAME    = "Audio LED Bar"
APP_VERSION = "1.0.0"
DEVELOPER   = "Mohamed Osama"
GITHUB_URL  = "https://github.com/OXVA/audio-led-bar"
NUM_BARS    = 32
NUM_LEDS    = 14
SAMPLE_RATE = 44100
BLOCK_SIZE  = 1024
FFT_SIZE    = 2048
SEND_INTERVAL_MS = 35
# ==========================================================



def _make_app_icon(size=64):
    """يرسم أيقونة الإيكولايزر ويرجعها كـ QIcon."""
    img = QImage(size, size, QImage.Format_ARGB32)
    img.fill(Qt.transparent)
    p = QPainter(img)
    p.setRenderHint(QPainter.Antialiasing)


    r = int(size * 0.18)
    p.setBrush(QBrush(QColor(13, 13, 20, 255)))
    p.setPen(Qt.NoPen)
    p.drawRoundedRect(0, 0, size, size, r, r)

    heights = [0.38, 0.52, 0.70, 0.88, 0.77, 0.63, 0.44, 0.32, 0.22]
    n = len(heights)
    ml = int(size * 0.10)
    aw = size - 2 * ml
    bw = int(aw / n * 0.68)
    bg = int(aw / n * 0.32)
    top = int(size * 0.13)
    bot = int(size * 0.70)
    ah  = bot - top

    colors = [
        QColor(0, 201, 122),  QColor(0, 201, 122),  QColor(0, 201, 122),
        QColor(0, 201, 122),  QColor(255, 210, 30),  QColor(255, 140, 20),
        QColor(255, 70, 40),  QColor(255, 50, 50),   QColor(255, 40, 40),
    ]
    for i, h in enumerate(heights):
        bh = int(ah * h)
        x  = ml + i * (bw + bg)
        y  = bot - bh
        p.setBrush(QBrush(colors[i]))
        p.drawRoundedRect(x, y, bw, bh, max(1, int(2 * size/64)), max(1, int(2 * size/64)))
        # peak dot
        pk = QColor(colors[i])
        pk.setAlpha(200)
        p.setBrush(QBrush(pk))
        p.drawRoundedRect(x, y - int(4 * size/64), bw, int(2 * size/64), 1, 1)


    sep = bot + int(6 * size/64)
    p.setPen(QPen(QColor(255, 255, 255, 30), max(1, int(size/64))))
    p.drawLine(ml, sep, size - ml, sep)

    ley = sep + int(5 * size/64)
    leh = int(8 * size/64)
    ln  = 9
    lw  = int(aw / ln * 0.65)
    lg  = int(aw / ln * 0.35)
    led_cols = [
        QColor(0, 201, 122), QColor(0, 201, 122), QColor(0, 201, 122),
        QColor(255, 210, 30), QColor(255, 210, 30), QColor(255, 140, 20),
        QColor(255, 60, 60), QColor(255, 50, 50), QColor(200, 40, 40, 150),
    ]
    p.setPen(Qt.NoPen)
    for i in range(ln):
        lx = ml + i * (lw + lg)
        p.setBrush(QBrush(led_cols[i]))
        p.drawRoundedRect(lx, ley, lw, leh, max(1, int(2*size/64)), max(1, int(2*size/64)))

    p.end()
    pix = QPixmap.fromImage(img)
    return QIcon(pix)



class AboutDialog(QDialog):
    def __init__(self, icon: QIcon, parent=None):
        super().__init__(parent)
        self.setWindowTitle(f"عن {APP_NAME}")
        self.setWindowIcon(icon)
        self.setFixedSize(420, 380)
        self.setStyleSheet("""
            QDialog { background-color: #0d0d14; }
            QLabel  { color: #c9c9d4; font-size: 13px; }
            QPushButton {
                background: #1c1c24; color: #e0e0e8;
                border: 1px solid #2e2e3a; border-radius: 6px;
                padding: 7px 20px; font-weight: 600;
            }
            QPushButton:hover { background: #26262f; }
        """)
        self._build()

    def _build(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(30, 30, 30, 20)
        layout.setSpacing(0)


        icon_lbl = QLabel()
        icon_lbl.setPixmap(
            _make_app_icon(96).pixmap(QSize(96, 96))
        )
        icon_lbl.setAlignment(Qt.AlignCenter)
        layout.addWidget(icon_lbl)
        layout.addSpacing(14)


        name_lbl = QLabel(APP_NAME)
        name_lbl.setAlignment(Qt.AlignCenter)
        name_lbl.setStyleSheet("color:#ffffff; font-size:20px; font-weight:bold;")
        layout.addWidget(name_lbl)
        layout.addSpacing(4)


        ver_lbl = QLabel(f"Version {APP_VERSION}")
        ver_lbl.setAlignment(Qt.AlignCenter)
        ver_lbl.setStyleSheet("color:#5a5a6e; font-size:12px;")
        layout.addWidget(ver_lbl)
        layout.addSpacing(22)


        sep = QWidget()
        sep.setFixedHeight(1)
        sep.setStyleSheet("background:#1e1e2a;")
        layout.addWidget(sep)
        layout.addSpacing(18)

        info_rows = [
            ("👨‍💻  المطور",    DEVELOPER),
            ("🔧  التقنيات", "Python · PyQt5 · NumPy · Arduino"),
            ("📡  البروتوكول","Serial USB @ 9600 baud"),
            ("🌐  GitHub",   GITHUB_URL),
        ]
        for label, value in info_rows:
            row = QHBoxLayout()
            lbl = QLabel(label)
            lbl.setFixedWidth(130)
            lbl.setStyleSheet("color:#5a5a6e; font-size:12px;")
            val = QLabel(value)
            val.setStyleSheet("color:#c9c9d4; font-size:12px;")
            val.setWordWrap(True)
            if value == GITHUB_URL:
                val.setText(f'<a href="{GITHUB_URL}" style="color:#00c474;">{GITHUB_URL}</a>')
                val.setOpenExternalLinks(True)
            row.addWidget(lbl)
            row.addWidget(val, 1)
            layout.addLayout(row)
            layout.addSpacing(8)

        layout.addSpacing(10)
        sep2 = QWidget()
        sep2.setFixedHeight(1)
        sep2.setStyleSheet("background:#1e1e2a;")
        layout.addWidget(sep2)
        layout.addSpacing(16)

        # ── زر إغلاق ──
        close_btn = QPushButton("إغلاق")
        close_btn.clicked.connect(self.accept)
        close_btn.setFixedWidth(110)
        row_btn = QHBoxLayout()
        row_btn.addStretch()
        row_btn.addWidget(close_btn)
        layout.addLayout(row_btn)



class AudioEngine(QObject):
    spectrum_ready = pyqtSignal(np.ndarray, float)

    def __init__(self):
        super().__init__()
        self.stream = None
        self.running = False
        self.smoothed = np.zeros(NUM_BARS)
        self.freqs = np.fft.rfftfreq(FFT_SIZE, 1 / SAMPLE_RATE)
        self.band_edges = np.logspace(np.log10(20), np.log10(SAMPLE_RATE / 2), NUM_BARS + 1)
        self.sensitivity = 1.0
        self.noise_floor_db  = -70.0
        self.dynamic_range_db = 38.0
        self.gate_threshold  = 0.025
        self.volume_smoothed = 0.0

    def start(self, device_index=None):
        self.running = True
        self.stream = sd.InputStream(
            device=device_index, channels=1, samplerate=SAMPLE_RATE,
            blocksize=BLOCK_SIZE, callback=self._callback)
        self.stream.start()

    def stop(self):
        self.running = False
        if self.stream:
            self.stream.stop()
            self.stream.close()
            self.stream = None

    def _callback(self, indata, frames, time_info, status):
        if not self.running:
            return
        samples = indata[:, 0]
        rms = float(np.sqrt(np.mean(samples ** 2)) + 1e-9)
        db  = 20.0 * np.log10(rms)

        if db < self.noise_floor_db:
            self.noise_floor_db = db
        else:
            self.noise_floor_db += (db - self.noise_floor_db) * 0.002

        ceil_db  = self.noise_floor_db + (self.dynamic_range_db / max(self.sensitivity, 0.05))
        norm_vol = float(np.clip(
            (db - self.noise_floor_db) / max(ceil_db - self.noise_floor_db, 1e-6),
            0.0, 1.0))
        if norm_vol < self.gate_threshold:
            norm_vol = 0.0

        self.volume_smoothed = (norm_vol if norm_vol > self.volume_smoothed
                                else self.volume_smoothed * 0.8 + norm_vol * 0.2)

        padded = np.zeros(FFT_SIZE)
        n = min(len(samples), FFT_SIZE)
        padded[:n] = samples[:n]
        windowed = padded * np.hanning(FFT_SIZE)
        spectrum = np.abs(np.fft.rfft(windowed))

        shape = np.zeros(NUM_BARS)
        for i in range(NUM_BARS):
            mask = (self.freqs >= self.band_edges[i]) & (self.freqs < self.band_edges[i + 1])
            if np.any(mask):
                shape[i] = np.mean(spectrum[mask])
        shape = np.log1p(shape)
        if shape.max() > 0:
            shape = shape / (shape.max() + 1e-6)

        bands = shape * self.volume_smoothed
        rise  = bands > self.smoothed
        self.smoothed[rise]  = bands[rise]
        self.smoothed[~rise] = self.smoothed[~rise] * 0.75 + bands[~rise] * 0.25
        self.spectrum_ready.emit(self.smoothed.copy(), self.volume_smoothed)



class EqualizerWidget(QWidget):
    def __init__(self):
        super().__init__()
        self.levels = np.zeros(NUM_BARS)
        self.peaks  = np.zeros(NUM_BARS)
        self.setMinimumHeight(280)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)

    def update_levels(self, levels):
        self.levels = levels
        self.peaks  = np.maximum(self.peaks - 0.018, levels)
        self.update()

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        w, h = self.width(), self.height()
        p.fillRect(self.rect(), QColor(13, 13, 18))

        p.setPen(QPen(QColor(35, 35, 42), 1))
        for frac in (0.25, 0.5, 0.75):
            y = int(h * (1 - frac))
            p.drawLine(0, y, w, y)

        bw = w / NUM_BARS
        gap = bw * 0.25
        for i, lv in enumerate(self.levels):
            bh  = lv * (h - 16)
            x   = i * bw + gap / 2
            bww = bw - gap
            grad = QLinearGradient(0, h, 0, 0)
            grad.setColorAt(0.0,  QColor(0, 220, 130))
            grad.setColorAt(0.55, QColor(255, 210, 0))
            grad.setColorAt(0.85, QColor(255, 120, 0))
            grad.setColorAt(1.0,  QColor(255, 35, 35))
            p.setBrush(QBrush(grad))
            p.setPen(Qt.NoPen)
            p.drawRoundedRect(int(x), int(h - bh), int(bww), int(bh) + 2, 3, 3)
            py = h - self.peaks[i] * (h - 16)
            p.setPen(QPen(QColor(255, 255, 255, 220), 2))
            p.drawLine(int(x), int(py), int(x + bww), int(py))



class LedLevelWidget(QWidget):
    def __init__(self):
        super().__init__()
        self.level = 0
        self.setFixedHeight(46)

    def set_level(self, level):
        self.level = level
        self.update()

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        w, h = self.width(), self.height()
        sw = w / NUM_LEDS
        gap = sw * 0.15
        for i in range(NUM_LEDS):
            on    = i < self.level
            ratio = i / NUM_LEDS
            if ratio < 0.55:
                col = QColor(0, 220, 130) if on else QColor(25, 45, 35)
            elif ratio < 0.8:
                col = QColor(255, 210, 0)  if on else QColor(45, 40, 20)
            else:
                col = QColor(255, 40, 40)  if on else QColor(45, 22, 22)
            x = i * sw + gap / 2
            p.setBrush(QBrush(col))
            p.setPen(Qt.NoPen)
            p.drawRoundedRect(int(x), 4, int(sw - gap), h - 8, 4, 4)


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self._icon = _make_app_icon(64)
        self.setWindowTitle(f"{APP_NAME}  •  Studio by Mohamed Osama")
        self.setWindowIcon(self._icon)
        self.resize(880, 580)

        self.audio = AudioEngine()
        self.audio.spectrum_ready.connect(self.on_spectrum)

        self.arduino       = None
        self.last_led_level = -1
        self.pending_level  = 0
        self.send_timer = QTimer()
        self.send_timer.setInterval(SEND_INTERVAL_MS)
        self.send_timer.timeout.connect(self.flush_to_arduino)
        self.send_timer.start()

        self._build_menu()
        self._build_ui()
        self._apply_style()
        self.refresh_devices()
        self.refresh_ports()

    def _build_menu(self):
        menubar = self.menuBar()
        menubar.setStyleSheet("""
            QMenuBar { background:#0d0d14; color:#c9c9d4; font-size:13px; }
            QMenuBar::item:selected { background:#1c1c24; border-radius:4px; }
            QMenu { background:#1c1c24; color:#c9c9d4; border:1px solid #2e2e3a; }
            QMenu::item:selected { background:#2a2a36; }
        """)
        help_menu = menubar.addMenu("مساعدة")
        about_action = QAction(self._icon, "عن المطور", self)
        about_action.triggered.connect(self.show_about)
        help_menu.addAction(about_action)

    def _build_ui(self):
        central = QWidget()
        self.setCentralWidget(central)
        root = QVBoxLayout(central)
        root.setContentsMargins(18, 12, 18, 18)
        root.setSpacing(14)

        top_row = QHBoxLayout()
        title_col = QVBoxLayout()
        title = QLabel(APP_NAME.upper())
        title.setObjectName("title")
        subtitle = QLabel("Real-time microphone equalizer → Arduino LED bar")
        subtitle.setObjectName("subtitle")
        title_col.addWidget(title)
        title_col.addWidget(subtitle)
        top_row.addLayout(title_col, 1)

        about_btn = QPushButton("ℹ  عن المطور")
        about_btn.setObjectName("aboutBtn")
        about_btn.clicked.connect(self.show_about)
        about_btn.setFixedHeight(36)
        top_row.addWidget(about_btn, 0, Qt.AlignBottom)
        root.addLayout(top_row)

        row1 = QHBoxLayout()
        row1.addWidget(QLabel("جهاز الصوت:"))
        self.device_combo = QComboBox()
        row1.addWidget(self.device_combo, 1)
        btn_rd = QPushButton("تحديث")
        btn_rd.clicked.connect(self.refresh_devices)
        row1.addWidget(btn_rd)
        root.addLayout(row1)

        row2 = QHBoxLayout()
        row2.addWidget(QLabel("بورت الأردوينو:"))
        self.port_combo = QComboBox()
        row2.addWidget(self.port_combo, 1)
        btn_rp = QPushButton("تحديث")
        btn_rp.clicked.connect(self.refresh_ports)
        row2.addWidget(btn_rp)
        root.addLayout(row2)

        row3 = QHBoxLayout()
        self.start_btn = QPushButton("▶  ابدأ")
        self.start_btn.setObjectName("startBtn")
        self.start_btn.clicked.connect(self.toggle_run)
        row3.addWidget(self.start_btn)
        self.status_label = QLabel("غير متصل")
        self.status_label.setObjectName("status")
        row3.addWidget(self.status_label, 1, Qt.AlignRight)
        root.addLayout(row3)

        self.eq_widget = EqualizerWidget()
        root.addWidget(self.eq_widget, 1)

        row4 = QHBoxLayout()
        row4.addWidget(QLabel("الحساسية:"))
        self.sens_slider = QSlider(Qt.Horizontal)
        self.sens_slider.setRange(10, 300)
        self.sens_slider.setValue(100)
        self.sens_slider.valueChanged.connect(self.on_sensitivity_change)
        row4.addWidget(self.sens_slider, 1)
        root.addLayout(row4)

        root.addWidget(QLabel("شريط اللمبات (اللي بيتبعت للأردوينو):"))
        self.led_widget = LedLevelWidget()
        root.addWidget(self.led_widget)

    def _apply_style(self):
        self.setStyleSheet("""
            QMainWindow  { background-color: #0d0d12; }
            QWidget      { background-color: #0d0d12; }
            QLabel       { color: #c9c9d4; font-size: 13px; }
            #title       { color: #ffffff; font-size: 24px; font-weight: bold; }
            #subtitle    { color: #7a7a8c; font-size: 12px; margin-bottom: 4px; }
            #status      { color: #ff5050; font-weight: bold; }
            QComboBox {
                background:#1c1c24; color:#e0e0e8;
                border:1px solid #2e2e3a; border-radius:6px; padding:6px 10px;
            }
            QPushButton {
                background:#1c1c24; color:#e0e0e8;
                border:1px solid #2e2e3a; border-radius:6px;
                padding:7px 16px; font-weight:600;
            }
            QPushButton:hover  { background:#26262f; }
            #startBtn  { background:#00c474; color:#06140d; border:none; }
            #startBtn:hover { background:#00e085; }
            #aboutBtn  { background:#1c1c2e; color:#9090c0; border:1px solid #2e2e4a;
                          border-radius:6px; padding:6px 14px; font-size:12px; }
            #aboutBtn:hover { background:#24243a; color:#b0b0e0; }
            QSlider::groove:horizontal { height:6px; background:#2e2e3a; border-radius:3px; }
            QSlider::handle:horizontal {
                background:#00c474; width:16px; margin:-6px 0; border-radius:8px;
            }
        """)

    def show_about(self):
        dlg = AboutDialog(self._icon, self)
        dlg.exec_()

    def refresh_devices(self):
        self.device_combo.clear()
        for idx, dev in enumerate(sd.query_devices()):
            if dev["max_input_channels"] > 0:
                self.device_combo.addItem(dev["name"], idx)

    def refresh_ports(self):
        self.port_combo.clear()
        ports = serial.tools.list_ports.comports()
        for p in ports:
            self.port_combo.addItem(f"{p.device} — {p.description}", p.device)
        if not ports:
            self.port_combo.addItem("مفيش بورتات متاحة", None)

    def on_sensitivity_change(self, value):
        self.audio.sensitivity = value / 100.0

    def toggle_run(self):
        if not self.audio.running:
            self.start_session()
        else:
            self.stop_session()

    def start_session(self):
        port = self.port_combo.currentData()
        if port:
            try:
                self.arduino = serial.Serial(port, 9600, timeout=1)
                self.status_label.setText(f"متصل — {port}")
                self.status_label.setStyleSheet("color:#00e085; font-weight:bold;")
            except serial.SerialException as e:
                self.status_label.setText(f"فشل الاتصال: {e}")
                self.status_label.setStyleSheet("color:#ff5050; font-weight:bold;")
                self.arduino = None
        else:
            self.status_label.setText("معاينة — بدون أردوينو")
            self.status_label.setStyleSheet("color:#ffb300; font-weight:bold;")

        self.audio.start(device_index=self.device_combo.currentData())
        self.start_btn.setText("⏸  إيقاف")

    def stop_session(self):
        self.audio.stop()
        if self.arduino:
            self.arduino.close()
            self.arduino = None
        self.led_widget.set_level(0)
        self.status_label.setText("غير متصل")
        self.status_label.setStyleSheet("color:#ff5050; font-weight:bold;")
        self.start_btn.setText("▶  ابدأ")

    def on_spectrum(self, bands, volume):
        self.eq_widget.update_levels(bands)
        level = int(round(volume * NUM_LEDS))
        self.led_widget.set_level(level)
        self.pending_level = level

    def flush_to_arduino(self):
        if self.arduino and self.pending_level != self.last_led_level:
            try:
                self.arduino.write(f"{self.pending_level}\n".encode())
                self.last_led_level = self.pending_level
            except serial.SerialException:
                pass

    def closeEvent(self, event):
        self.stop_session()
        event.accept()


def main():
    app = QApplication(sys.argv)
    app.setFont(QFont("Segoe UI", 10))
    win = MainWindow()
    win.show()
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
