const int numLeds = 18;
const int ledPins[numLeds] = {A0, A1, A2, A3, A4, A5, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13};

int currentLevel = 0;
unsigned long lastUpdate = 0;
const int decayInterval = 40; 

void setup() {
  for (int i = 0; i < numLeds; i++) {
    pinMode(ledPins[i], OUTPUT);
    digitalWrite(ledPins[i], LOW);
  }
  Serial.begin(9600);
}

void updateBar(int level) {
  level = constrain(level, 0, numLeds);
  for (int i = 0; i < numLeds; i++) {
    digitalWrite(ledPins[i], i < level ? HIGH : LOW);
  }
}

void loop() {
  if (Serial.available() > 0) {
    String data = Serial.readStringUntil('\n');
    int newLevel = data.toInt();
    if (newLevel >= 0 && newLevel <= numLeds) {
      currentLevel = newLevel;
      updateBar(currentLevel);
      lastUpdate = millis();
    }
  }


  if (millis() - lastUpdate > decayInterval && currentLevel > 0) {
    currentLevel--;
    updateBar(currentLevel);
    lastUpdate = millis();
  }
}
